library('testthat')
test_check('comorbidities.icd10')
